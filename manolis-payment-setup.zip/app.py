"""Core FastAPI integration service. Initialize/seed explicitly before using."""
import hashlib
import hmac
import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request as ProviderRequest, urlopen
import os
import secrets
from collections import defaultdict
from contextlib import asynccontextmanager
from decimal import Decimal
from typing import Annotated, Literal
from uuid import UUID

from fastapi import Depends, FastAPI, HTTPException, Request, Security
from fastapi.middleware.cors import CORSMiddleware
from starlette.concurrency import run_in_threadpool
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from schema import Base, Branch, IngredientStock, LedgerEntry, MobilePrompt, Order, OrderEvent, PaymentIntent, Product, StockMovement

engine = None
bearer = HTTPBearer(auto_error=False)
STAGES = ("New", "Confirmed", "Preparing", "Ready", "Completed")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    global engine
    url = os.environ.get("DATABASE_URL")
    if url:
        if url.startswith("postgres://"):
            url = "postgresql+psycopg://" + url.removeprefix("postgres://")
        elif url.startswith("postgresql://"):
            url = "postgresql+psycopg://" + url.removeprefix("postgresql://")
        engine = create_engine(url, pool_pre_ping=True)
        if os.environ.get("INIT_SCHEMA") == "1":
            Base.metadata.create_all(engine)
    yield
    if engine is not None:
        engine.dispose()
        engine = None


app = FastAPI(title="MANOLIS order integration", version="0.2.0", lifespan=lifespan)
if origin := os.environ.get("STOREFRONT_ORIGIN"):
    app.add_middleware(CORSMiddleware, allow_origins=[origin], allow_methods=["GET", "POST"], allow_headers=["Content-Type"])


def session():
    if engine is None:
        raise HTTPException(503, "Database unavailable")
    with Session(engine, expire_on_commit=False) as db:
        yield db


DB = Annotated[Session, Depends(session)]


def is_staff(credentials: HTTPAuthorizationCredentials | None) -> bool:
    token = os.environ.get("WORKSPACE_TOKEN")
    return bool(token and credentials and secrets.compare_digest(token, credentials.credentials))


def staff(credentials: Annotated[HTTPAuthorizationCredentials | None, Security(bearer)]):
    if not is_staff(credentials):
        raise HTTPException(401, "Workspace access required")


class Item(BaseModel):
    product_id: str = Field(min_length=1, max_length=36)
    quantity: int = Field(ge=1, le=99)
    extras: list[str] = Field(default_factory=list, max_length=16)
    note: str = Field(default="", max_length=160)


class Checkout(BaseModel):
    request_key: UUID
    branch_id: str = Field(min_length=1, max_length=36)
    customer_name: str = Field(min_length=1, max_length=80)
    address: str = Field(default="", max_length=180)
    channel: Literal["Online", "Walk-in", "Takeaway", "Dine-in"]
    fulfillment: Literal["Collection", "Delivery", "Walk-in", "Takeaway", "Dine-in"]
    payment: Literal["Cash", "Mobile money", "Card"]
    lines: list[Item] = Field(min_length=1, max_length=50)


class StatusUpdate(BaseModel):
    status: Literal["Confirmed", "Preparing", "Ready", "Completed", "Cancelled"]


def export(db: Session, order: Order, private=False) -> dict:
    history = db.scalars(select(OrderEvent).where(OrderEvent.order_no == order.number).order_by(OrderEvent.at)).all()
    result = {
        "id": order.public_id,
        "number": order.number,
        "branchId": order.branch_id,
        "channel": order.channel,
        "fulfillment": order.fulfillment,
        "payment": order.payment,
        "status": order.status,
        "gross": order.gross,
        "discount": order.discount,
        "total": order.total,
        "lines": [line if private else {key: value for key, value in line.items() if key not in ("recipe", "note")} for line in order.lines],
        "history": [{"status": stage, "at": event.at} for stage in (*STAGES, "Cancelled") for event in history if stage == event.status],
    }
    if private:
        result.update(name=order.customer_name, address=order.address)
    return result


@app.get("/health")
def health():
    return {"status": "ok", "database_configured": engine is not None}


@app.get("/menu")
def menu(db: DB):
    return [
        {"id": p.id, "name": p.name, "category": p.category, "description": p.description, "image": p.image, "price": p.price,
         "extras": [{"id": e["id"], "name": e["name"], "price": e["price"]} for e in p.extras]}
        for p in db.scalars(select(Product).where(Product.active).order_by(Product.name))
    ]


def price_items(db: Session, items: list[Item]):
    lines = []
    for item in items:
        product = db.get(Product, item.product_id)
        if product is None or not product.active:
            raise HTTPException(409, "Menu item unavailable")
        extras = [extra for extra in product.extras if extra["id"] in item.extras]
        if len(extras) != len(set(item.extras)):
            raise HTTPException(409, "Menu extra unavailable")
        recipe = defaultdict(Decimal)
        for source in (product.recipe, *(extra.get("recipe", {}) for extra in extras)):
            for key, qty in source.items():
                recipe[key] += Decimal(str(qty))
        lines.append({
            "productId": product.id, "name": product.name, "category": product.category, "quantity": item.quantity,
            "price": product.price, "station": product.station, "note": item.note, "recipe": {key: str(qty) for key, qty in recipe.items()},
            "extras": [{"id": e["id"], "name": e["name"], "price": e["price"]} for e in extras],
        })
    total = sum((line["price"] + sum(e["price"] for e in line["extras"])) * line["quantity"] for line in lines)
    return lines, total


@app.post("/orders")
def checkout(payload: Checkout, db: DB, credentials: Annotated[HTTPAuthorizationCredentials | None, Security(bearer)]):
    if os.environ.get("ENABLE_STOREFRONT_PAYMENTS") == "1":
        raise HTTPException(409, "Use the verified payment checkout")
    counter = payload.channel != "Online"
    if counter and not is_staff(credentials):
        raise HTTPException(401, "Workspace access required")
    if not payload.customer_name.strip() or (payload.fulfillment == "Delivery" and not payload.address.strip()):
        raise HTTPException(422, "Name and a delivery address, when applicable, are required")
    if (counter and payload.fulfillment != payload.channel) or (not counter and payload.fulfillment not in ("Collection", "Delivery")):
        raise HTTPException(422, "Fulfillment and channel do not match")
    fingerprint = hashlib.sha256(payload.model_dump_json().encode()).hexdigest()
    with db.begin():
        branch = db.scalar(select(Branch).where(Branch.id == payload.branch_id).with_for_update())
        if branch is None:
            raise HTTPException(404, "Branch unavailable")
        existing = db.scalar(select(Order).where(Order.branch_id == branch.id, Order.request_key == str(payload.request_key)))
        if existing:
            if existing.fingerprint != fingerprint:
                raise HTTPException(409, "Idempotency key already used for a different order")
            return export(db, existing, private=counter)
        lines, total = price_items(db, payload.lines)
        order = Order(request_key=str(payload.request_key), fingerprint=fingerprint, branch_id=branch.id, customer_name=payload.customer_name,
                      address=payload.address, channel=payload.channel, fulfillment=payload.fulfillment, payment=payload.payment,
                      status="Confirmed" if counter else "New", gross=total, total=total, lines=lines)
        db.add(order)
        db.flush()
        db.add(OrderEvent(order_no=order.number, status="New", actor="Workspace" if counter else "Customer"))
        if counter:
            db.add(OrderEvent(order_no=order.number, status="Confirmed", actor="Workspace"))
            db.add(LedgerEntry(order_no=order.number, kind="Sale", amount=order.total))
        return export(db, order, private=counter)


@app.get("/orders/{tracking_id}")
def track(tracking_id: UUID, db: DB):
    order = db.scalar(select(Order).where(Order.public_id == str(tracking_id)))
    if order is None:
        raise HTTPException(404, "Order unavailable")
    return export(db, order)


@app.get("/workspace/orders", dependencies=[Depends(staff)])
def queue(db: DB, branch_id: str):
    return [export(db, order, private=True) for order in db.scalars(select(Order).where(Order.branch_id == branch_id).order_by(Order.number.desc()))]


@app.patch("/workspace/orders/{tracking_id}", dependencies=[Depends(staff)])
def change_status(tracking_id: UUID, payload: StatusUpdate, db: DB):
    with db.begin():
        order = db.scalar(select(Order).where(Order.public_id == str(tracking_id)).with_for_update())
        if order is None:
            raise HTTPException(404, "Order unavailable")
        if payload.status == order.status:
            return export(db, order, private=True)
        if order.status in ("Cancelled", "Completed"):
            raise HTTPException(409, "This order is closed")
        if payload.status == "Cancelled":
            if db.scalar(select(PaymentIntent).where(PaymentIntent.order_no == order.number)):
                raise HTTPException(409, "Resolve the captured payment before cancelling this order")
            if order.status == "Ready":
                raise HTTPException(409, "A ready order cannot be voided")
            if order.channel != "Online":
                db.add(LedgerEntry(order_no=order.number, kind="Void", amount=order.total))
        elif STAGES.index(payload.status) != STAGES.index(order.status) + 1:
            raise HTTPException(409, "Order status is out of sequence")
        if payload.status == "Completed":
            usage = defaultdict(Decimal)
            for line in order.lines:
                for key, qty in line["recipe"].items():
                    usage[key] += Decimal(qty) * line["quantity"]
            for key in sorted(usage):
                stock = db.scalar(select(IngredientStock).where(IngredientStock.branch_id == order.branch_id, IngredientStock.ingredient_id == key).with_for_update())
                if stock is None or usage[key] > stock.available or usage[key] < 0:
                    raise HTTPException(409, "Configured recipe stock is unavailable")
                stock.available -= usage[key]
                db.add(StockMovement(order_no=order.number, branch_id=order.branch_id, ingredient_id=key, delta=-usage[key]))
            if order.channel == "Online" and not db.scalar(select(LedgerEntry).where(LedgerEntry.order_no == order.number, LedgerEntry.kind == "Sale")):
                db.add(LedgerEntry(order_no=order.number, kind="Sale", amount=order.total))
        order.status = payload.status
        db.add(OrderEvent(order_no=order.number, status=payload.status, actor="Workspace"))
        return export(db, order, private=True)


class PaymentCheckout(BaseModel):
    request_key: UUID
    method: Literal["Mobile money", "Card", "Bank transfer"]
    branch: str = Field(min_length=1, max_length=36)
    name: str = Field(min_length=1, max_length=80)
    email: str = Field(default="", max_length=254)
    amount: int = Field(gt=0)
    lines: list[Item] = Field(min_length=1, max_length=50)


class BankConfirmation(BaseModel):
    statement_id: str = Field(min_length=1, max_length=130)
    amount: int = Field(gt=0)
    currency: Literal["ZMW"]


def payment_enabled():
    if os.environ.get("ENABLE_STOREFRONT_PAYMENTS") != "1":
        raise HTTPException(503, "Storefront payments are not configured")


def bank_details():
    details = {key: os.environ.get(env) for key, env in (
        ("bank", "COLLECTION_BANK_NAME"), ("accountName", "COLLECTION_BANK_ACCOUNT_NAME"),
        ("accountNumber", "COLLECTION_BANK_ACCOUNT_NUMBER"))}
    if not all(details.values()):
        raise HTTPException(503, "Bank transfers are unavailable")
    return details


def lenco_config(require_public=True):
    key = os.environ.get("LENCO_PUBLIC_KEY")
    secret = os.environ.get("LENCO_SECRET_KEY")
    if not secret or (require_public and not key):
        raise HTTPException(503, "Lenco checkout is unavailable")
    return key, secret, os.environ.get("LENCO_SANDBOX", "1") != "0"


def payment_view(db: Session, record: PaymentIntent):
    data = {"reference": record.reference, "amount": record.amount, "currency": "ZMW", "status": "pending"}
    if record.order_no is not None:
        order = db.get(Order, record.order_no)
        sale = db.scalar(select(LedgerEntry).where(LedgerEntry.order_no == order.number, LedgerEntry.kind == "Sale"))
        receipt = {
            "number": order.number, "name": order.customer_name, "method": "Bank card" if order.payment == "Card" else order.payment,
            "total": order.total, "subtotal": order.gross, "discount": order.discount,
            "issuedAt": sale.at if sale else order.created_at, "reference": record.reference,
            "status": "Paid", "demo": record.method != "Bank transfer" and os.environ.get("LENCO_SANDBOX", "1") != "0",
            "fulfillment": order.fulfillment,
            "items": [{"name": line["name"], "quantity": line["quantity"],
                       "amount": (line["price"] + sum(e["price"] for e in line["extras"])) * line["quantity"],
                       "extras": [e["name"] for e in line["extras"]]} for line in order.lines],
        }
        return {**data, "status": "paid", "order": {"id": order.public_id, "number": order.number, "receipt": receipt}}
    if record.method == "Bank transfer":
        return {**data, "bank": bank_details()}
    key, _, sandbox = lenco_config(require_public=record.method == "Card")
    if record.method == "Mobile money":
        return {**data, "sandbox": sandbox}
    return {**data, "publicKey": key, "sandbox": sandbox}


@app.post("/payment-intents", dependencies=[Depends(payment_enabled)])
def init_payment(payload: PaymentCheckout, db: DB):
    if not payload.name.strip():
        raise HTTPException(422, "Enter your name for collection")
    if payload.method == "Bank transfer":
        bank_details()
    else:
        lenco_config(require_public=payload.method == "Card")
        if payload.method == "Card" and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", payload.email.strip()):
            raise HTTPException(422, "Enter an email for your receipt")
    fingerprint = hashlib.sha256(payload.model_dump_json().encode()).hexdigest()
    reference = str(payload.request_key)
    with db.begin():
        branch = db.scalar(select(Branch).where(Branch.id == payload.branch).with_for_update())
        if branch is None:
            raise HTTPException(404, "Branch unavailable")
        record = db.get(PaymentIntent, reference)
        if record is not None:
            if record.fingerprint != fingerprint:
                raise HTTPException(409, "This reference is already in use")
            return payment_view(db, record)
        lines, amount = price_items(db, payload.lines)
        if amount <= 0 or amount != payload.amount:
            raise HTTPException(409, "The server menu price differs from this basket. Refresh the menu before paying.")
        record = PaymentIntent(reference=reference, fingerprint=fingerprint, method=payload.method, branch_id=branch.id,
                               customer_name=payload.name.strip(), amount=amount, lines=lines)
        db.add(record)
        return payment_view(db, record)


def verified_lenco_reference(reference: str, amount: int, method: str):
    _, secret, sandbox = lenco_config(require_public=False)
    host = "api.sandbox.lenco.co" if sandbox else "api.lenco.co"
    request = ProviderRequest(f"https://{host}/access/v2/collections/status/{quote(reference, safe='')}",
                      headers={"Authorization": "Bearer " + secret, "Accept": "application/json"})
    try:
        with urlopen(request, timeout=8) as response:
            result = json.load(response)
    except HTTPError as error:
        if error.code == 404:
            return None
        raise HTTPException(502, "Could not verify payment with Lenco") from None
    except (URLError, TimeoutError, ValueError):
        raise HTTPException(502, "Could not verify payment with Lenco") from None
    data = result.get("data") or {}
    if not result.get("status") or data.get("reference") != reference:
        return None
    if data.get("status") == "failed":
        return "failed"
    if data.get("status") != "successful":
        return None
    expected_type = "mobile-money" if method == "Mobile money" else "card"
    if (data.get("reference") != reference or data.get("currency") != "ZMW" or data.get("type") != expected_type
        or str(data.get("amount", "")).strip() == "" or not data.get("id")):
        raise HTTPException(409, "The provider payment details did not match this order")
    try:
        matches = Decimal(str(data["amount"]))*100 == amount
    except ArithmeticError:
        matches = False
    if not matches:
        raise HTTPException(409, "The provider payment amount did not match this order")
    return "lenco:" + str(data["id"])


def capture_verified(db: Session, record: PaymentIntent, provider_reference: str):
    if record.order_no is not None:
        return payment_view(db, record)
    if db.scalar(select(PaymentIntent.reference).where(PaymentIntent.provider_reference == provider_reference)):
        raise HTTPException(409, "This payment is already linked to another order")
    order = Order(request_key=record.reference, fingerprint=record.fingerprint, branch_id=record.branch_id,
                  customer_name=record.customer_name, address="", channel="Online", fulfillment="Collection",
                  payment=record.method, status="New", gross=record.amount, total=record.amount, lines=record.lines)
    db.add(order)
    db.flush()
    record.order_no = order.number
    record.provider_reference = provider_reference
    db.add_all([OrderEvent(order_no=order.number, status="New", actor="Verified payment"),
                LedgerEntry(order_no=order.number, kind="Sale", amount=order.total)])
    return payment_view(db, record)


def locked_payment(db: Session, reference: UUID):
    record = db.scalar(select(PaymentIntent).where(PaymentIntent.reference == str(reference)).with_for_update())
    if record is None:
        raise HTTPException(404, "Payment reference unavailable")
    return record


class MobilePromptInput(BaseModel):
    phone: str = Field(max_length=20)
    operator: Literal["airtel", "mtn", "zamtel"]


def request_lenco_prompt(reference: str, amount: int, phone: str, operator: str):
    _, secret, sandbox = lenco_config(require_public=False)
    host = "api.sandbox.lenco.co" if sandbox else "api.lenco.co"
    payload = {"amount": amount / 100, "reference": reference, "phone": phone,
               "operator": operator, "country": "zm", "bearer": "merchant"}
    request = ProviderRequest(f"https://{host}/access/v2/collections/mobile-money", data=json.dumps(payload).encode(),
                              headers={"Authorization": "Bearer " + secret, "Content-Type": "application/json", "Accept": "application/json"})
    try:
        with urlopen(request, timeout=8) as response:
            result = json.load(response)
    except (HTTPError, URLError, TimeoutError, ValueError):
        raise HTTPException(502, "Could not confirm that the prompt was sent. Check payment status before trying again.") from None
    if not result.get("status"):
        raise HTTPException(502, "The provider did not confirm the prompt. Check payment status.")


@app.post("/payment-intents/{reference}/mobile-prompt", dependencies=[Depends(payment_enabled)])
def mobile_prompt(reference: UUID, payload: MobilePromptInput, db: DB):
    clean = re.sub(r"[\s()-]", "", payload.phone.strip())
    match = re.fullmatch(r"(?:0|\+?260)([79][0-9]{8})", clean)
    if not match:
        raise HTTPException(422, "Enter a valid Zambian mobile number")
    lenco_config(require_public=False)
    with db.begin():
        record = locked_payment(db, reference)
        if record.method != "Mobile money":
            raise HTTPException(409, "This order does not use mobile money")
        if record.order_no is not None or db.get(MobilePrompt, str(reference)):
            return payment_view(db, record)
        db.add(MobilePrompt(reference=str(reference)))
        amount = record.amount
    request_lenco_prompt(str(reference), amount, "0" + match.group(1), payload.operator)
    return payment_status(reference, db)


@app.get("/payment-intents/{reference}", dependencies=[Depends(payment_enabled)])
def payment_status(reference: UUID, db: DB):
    with db.begin():
        record = locked_payment(db, reference)
        if record.order_no is not None or record.method == "Bank transfer":
            return payment_view(db, record)
        provider_reference = verified_lenco_reference(record.reference, record.amount, record.method)
        if provider_reference == "failed":
            return {**payment_view(db, record), "status": "failed"}
        if provider_reference:
            return capture_verified(db, record, provider_reference)
        return payment_view(db, record)


@app.post("/workspace/payment-intents/{reference}/confirm-bank", dependencies=[Depends(payment_enabled), Depends(staff)])
def confirm_bank(reference: UUID, payload: BankConfirmation, db: DB):
    with db.begin():
        record = locked_payment(db, reference)
        statement_id = payload.statement_id.strip()
        if record.method != "Bank transfer" or payload.amount != record.amount or not statement_id:
            raise HTTPException(422, "Bank statement details must match this order")
        verified_reference = "bank:" + statement_id
        if record.order_no is not None and record.provider_reference != verified_reference:
            raise HTTPException(409, "This order already has a confirmed bank payment")
        return capture_verified(db, record, verified_reference)


@app.post("/payment-webhooks/lenco", dependencies=[Depends(payment_enabled)])
async def lenco_webhook(request: Request, db: DB):
    _, secret, _ = lenco_config(require_public=False)
    body = await request.body()
    if len(body) > 65_536:
        raise HTTPException(413, "Event too large")
    key = hashlib.sha256(secret.encode()).hexdigest().encode()
    signature = hmac.new(key, body, hashlib.sha512).hexdigest()
    if not hmac.compare_digest(signature, request.headers.get("X-Lenco-Signature", "")):
        raise HTTPException(401, "Invalid event signature")
    try:
        event = json.loads(body)
        if event.get("event") != "collection.successful":
            return {"received": True}
        reference = UUID(event["data"]["reference"])
    except (ValueError, KeyError, TypeError, AttributeError):
        return {"received": True}

    def process():
        with db.begin():
            record = db.scalar(select(PaymentIntent).where(PaymentIntent.reference == str(reference)).with_for_update())
            if record is None or record.order_no is not None or record.method == "Bank transfer":
                return
            provider_reference = verified_lenco_reference(record.reference, record.amount, record.method)
            if not provider_reference or provider_reference == "failed":
                raise HTTPException(503, "Payment is awaiting provider confirmation")
            capture_verified(db, record, provider_reference)

    await run_in_threadpool(process)
    return {"received": True}
