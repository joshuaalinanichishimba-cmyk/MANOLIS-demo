# MANOLIS payments setup

The accompanying index.html is a standalone GitHub Pages demo. In demo mode, staff sign-in, point of sale, kitchen, receipts and reports share browser data. Demo credentials are public. Do not enter real customer or payment data into demo forms.

## Storefront payment backend

This package adds an opt-in payment backend for collection orders. It includes a direct Lenco mobile-money collection adapter and a hosted Lenco widget for bank cards, and a bank-transfer workflow with human reconciliation. The browser-local staff screens remain a demo. Verified orders are available through the authenticated backend workspace API. Production staff identity, a server-connected POS, live refunds and an operational reconciliation process are still required before launching the full system.

1. Provision PostgreSQL and deploy the API over HTTPS. Install `requirements.txt` and run `uvicorn app:app --host 0.0.0.0 --port 8000` from this folder. Set `DATABASE_URL` and a strong server-only `WORKSPACE_TOKEN`.
2. Initialize the schema and catalog with `python seed_catalog.py < demo-catalog.json`. Replace the sample branch and prices with the restaurant's confirmed catalog. The single HTML demo uses branch ID `demo-ibex` and must show the same prices as the server. If they differ, the API refuses to start checkout.
   For an existing deployment rerun the schema initialization with `INIT_SCHEMA=1` on startup to create the new mobile prompt table.
3. Set `STOREFRONT_ORIGIN` to the exact scheme and host of the storefront. For GitHub Pages, omit the repository path and trailing slash.
4. For Lenco, set `LENCO_PUBLIC_KEY` and `LENCO_SECRET_KEY` on the server. Use `LENCO_SANDBOX=1` and the provider's test keys to check ZMW mobile-money and bank-card availability. Set `LENCO_SANDBOX=0` only after successful sandbox checks and merchant activation. Register the server's `/payment-webhooks/lenco` URL in Lenco. Confirm that your merchant credentials are enabled for collecting those payment methods in Zambia.
5. To enable manual bank transfer, set `COLLECTION_BANK_NAME`, `COLLECTION_BANK_ACCOUNT_NAME` and `COLLECTION_BANK_ACCOUNT_NUMBER` to the verified business account. Leave them blank to keep bank instructions disabled. Sandbox Lenco configuration does not mock a bank account, so use only controlled test details while testing.
6. Once the backend is ready, set `ENABLE_STOREFRONT_PAYMENTS=1` and edit the `manolis-payment-api` meta tag in `index.html`. Its content should be the public HTTPS base URL of the API. Never place the Lenco secret key or workspace token in the HTML.
7. Test checkout with approved sandbox numbers. Verify the phone approval flow, signed webhook reconciliation, and customer PDF download. Before production, apply rate limits to intent creation, mobile prompt requests and status checks. Verify the merchant dashboard gives staff a way to reconcile pending or interrupted attempts. A verified receipt creates one order and one sales ledger entry. If bank transfer is enabled, compare the actual cleared bank credit, reference, currency and amount before authorizing payment.

## Bank reconciliation

The customer sees an order-specific transfer reference, the exact amount and the configured bank details. A transfer stays pending until a staff member verifies the cleared deposit. Use the authenticated API operation `POST /workspace/payment-intents/{reference}/confirm-bank`. Supply the statement transaction identifier and amount in ngwee, for example `{"statement_id":"unique-cleared-statement-id","amount":10000,"currency":"ZMW"}`. Authenticate with the server workspace token. Use the actual statement transaction identifier once only. Use `GET /workspace/orders?branch_id=demo-ibex` to retrieve confirmed sales for fulfilment.

The API reprices items and extras on the server and verifies the provider's payment reference, amount, currency and method before posting a sale. For mobile money, the customer enters a number and selects Airtel, MTN or Zamtel. The backend requests authorization through Lenco using the server-calculated amount. The customer approves on their phone. MANOLIS never asks for the wallet PIN. The backend allows one mobile prompt submission per reference, verifies provider status and returns the receipt only after recording the payment. If initiation is interrupted, use the existing reference to reconcile in Lenco rather than prompting again for the same order. The standalone POS remains browser-local and records demo sales.

## Demo receipts and cash checkout

In Staff sign in choose Cashier, open a shift, add products and select Cash. Enter the cash received or select Exact cash, then choose Record cash sale. Download PDF or use Print receipt. Sales history opens previous cashier receipts. Customers can re-download paid receipts from their local order history. A cash order awaiting payment shows an order summary. PDF receipts do not show the customer wallet number.

Provider references

- [Lenco direct mobile-money collection](https://lenco-api.readme.io/v2.0/reference/initiate-collection-from-mobile-money)
- [Lenco payment widget](https://lenco-api.readme.io/v2.0/reference/accept-payments)
- [Lenco collection verification](https://lenco-api.readme.io/v2.0/reference/get-collection-by-reference)
- [Lenco webhook setup](https://lenco-api.readme.io/v2.0/reference/webhooks)
