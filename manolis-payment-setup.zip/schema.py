"""Core postgres persistence for the shared checkout and fulfillment boundary."""
from datetime import datetime
from decimal import Decimal
from uuid import uuid4

from sqlalchemy import JSON, CheckConstraint, DateTime, ForeignKey, Integer, Numeric, String, UniqueConstraint, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def new_id() -> str:
    return str(uuid4())


class Base(DeclarativeBase):
    pass


class Branch(Base):
    __tablename__ = "branches"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100))


class Product(Base):
    __tablename__ = "products"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    category: Mapped[str] = mapped_column(String(60))
    description: Mapped[str] = mapped_column(String(800), default="")
    image: Mapped[str] = mapped_column(String(450), default="")
    price: Mapped[int] = mapped_column(CheckConstraint("price >= 0"))
    station: Mapped[str] = mapped_column(String(80))
    active: Mapped[bool] = mapped_column(default=True)
    recipe: Mapped[dict] = mapped_column(JSON, default=dict)
    extras: Mapped[list] = mapped_column(JSON, default=list)


class IngredientStock(Base):
    __tablename__ = "ingredient_stock"
    branch_id: Mapped[str] = mapped_column(ForeignKey("branches.id"), primary_key=True)
    ingredient_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    unit: Mapped[str] = mapped_column(String(24))
    available: Mapped[Decimal] = mapped_column(Numeric(12, 3), CheckConstraint("available >= 0"))
    minimum: Mapped[Decimal] = mapped_column(Numeric(12, 3), default=0)


class Order(Base):
    __tablename__ = "orders"
    __table_args__ = (UniqueConstraint("branch_id", "request_key"),)
    number: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    public_id: Mapped[str] = mapped_column(String(36), default=new_id, unique=True)
    request_key: Mapped[str] = mapped_column(String(36))
    fingerprint: Mapped[str] = mapped_column(String(64))
    branch_id: Mapped[str] = mapped_column(ForeignKey("branches.id"), index=True)
    customer_name: Mapped[str] = mapped_column(String(80))
    address: Mapped[str] = mapped_column(String(180), default="")
    channel: Mapped[str] = mapped_column(String(24))
    fulfillment: Mapped[str] = mapped_column(String(24))
    payment: Mapped[str] = mapped_column(String(24))
    status: Mapped[str] = mapped_column(String(24), index=True)
    gross: Mapped[int] = mapped_column()
    total: Mapped[int] = mapped_column()
    discount: Mapped[int] = mapped_column(default=0)
    lines: Mapped[list] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class OrderEvent(Base):
    __tablename__ = "order_events"
    __table_args__ = (UniqueConstraint("order_no", "status"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    order_no: Mapped[int] = mapped_column(ForeignKey("orders.number"), index=True)
    status: Mapped[str] = mapped_column(String(24))
    actor: Mapped[str] = mapped_column(String(64))
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class LedgerEntry(Base):
    __tablename__ = "ledger_entries"
    __table_args__ = (UniqueConstraint("order_no", "kind"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    order_no: Mapped[int] = mapped_column(ForeignKey("orders.number"), index=True)
    kind: Mapped[str] = mapped_column(String(10))
    amount: Mapped[int] = mapped_column(CheckConstraint("amount >= 0"))
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class StockMovement(Base):
    __tablename__ = "stock_movements"
    __table_args__ = (UniqueConstraint("order_no", "ingredient_id"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    order_no: Mapped[int] = mapped_column(ForeignKey("orders.number"), index=True)
    branch_id: Mapped[str] = mapped_column(ForeignKey("branches.id"))
    ingredient_id: Mapped[str] = mapped_column(String(36))
    delta: Mapped[Decimal] = mapped_column(Numeric(12, 3))
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class PaymentIntent(Base):
    __tablename__ = "payment_intents"
    reference: Mapped[str] = mapped_column(String(36), primary_key=True)
    fingerprint: Mapped[str] = mapped_column(String(64))
    branch_id: Mapped[str] = mapped_column(ForeignKey("branches.id"), index=True)
    method: Mapped[str] = mapped_column(String(24))
    customer_name: Mapped[str] = mapped_column(String(80))
    amount: Mapped[int] = mapped_column(CheckConstraint("amount > 0"))
    lines: Mapped[list] = mapped_column(JSON)
    order_no: Mapped[int | None] = mapped_column(ForeignKey("orders.number"), unique=True)
    provider_reference: Mapped[str | None] = mapped_column(String(160), unique=True)


class MobilePrompt(Base):
    __tablename__ = "mobile_prompts"
    reference: Mapped[str] = mapped_column(ForeignKey("payment_intents.reference"), primary_key=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
